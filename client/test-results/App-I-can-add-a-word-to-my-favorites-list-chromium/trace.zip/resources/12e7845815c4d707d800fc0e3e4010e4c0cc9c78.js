import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FirestoreDemo.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4ea8f8d0"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { addWord, clearUser, getWords } from "/src/utils/api.ts";
import { getLoginCookie } from "/src/utils/cookie.ts";
export default function FirestoreDemo() {
  _s();
  const [words, setWords] = useState([]);
  const USER_ID = getLoginCookie() || "";
  useEffect(() => {
    getWords().then((data) => {
      setWords(data.words);
    });
  }, []);
  const addFavoriteWord = async (newWord) => {
    setWords([...words, newWord]);
    await addWord(newWord);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "firestore-demo", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Firestore Demo" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { htmlFor: "new-word", children: "Add a favorite word:" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("input", { "aria-label": "word-input", id: "new-word", type: "text" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "aria-label": "add-word-button", onClick: () => {
      const newWord = document.getElementById("new-word").value;
      addFavoriteWord(newWord);
    }, children: "Add" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: async () => {
      setWords([]);
      await clearUser();
    }, children: "Clear words" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: /* @__PURE__ */ jsxDEV("i", { "aria-label": "user-header", children: [
      "Favorite words for user ",
      USER_ID,
      ":"
    ] }, void 0, true, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 48,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { "aria-label": "favorite-words", children: words.map((word, index) => /* @__PURE__ */ jsxDEV("p", { "aria-label": "word", children: word }, index, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 51,
      columnNumber: 37
    }, this)) }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_s(FirestoreDemo, "QrHlQthZFfwcsWWYyDJIvsds8f8=");
_c = FirestoreDemo;
var _c;
$RefreshReg$(_c, "FirestoreDemo");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/FirestoreDemo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJOLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDN0MsU0FBU0Msc0JBQXNCO0FBTS9CLHdCQUF3QkMsZ0JBQWdCO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlSLFNBQW1CLEVBQUU7QUFFL0MsUUFBTVMsVUFBVUwsZUFBZSxLQUFLO0FBRXBDTCxZQUFVLE1BQU07QUFDZEksYUFBUyxFQUFFTyxLQUFNQyxVQUFTO0FBQ3hCSCxlQUFTRyxLQUFLSixLQUFLO0FBQUEsSUFDckIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFO0FBRUwsUUFBTUssa0JBQWtCLE9BQU9DLFlBQW9CO0FBRWpETCxhQUFTLENBQUMsR0FBR0QsT0FBT00sT0FBTyxDQUFDO0FBRTVCLFVBQU1aLFFBQVFZLE9BQU87QUFBQSxFQUN2QjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkJBQUMsUUFBRyw4QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFFbEIsdUJBQUMsV0FBTSxTQUFRLFlBQVcsb0NBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEM7QUFBQSxJQUM5Qyx1QkFBQyxXQUFNLGNBQVcsY0FBYSxJQUFHLFlBQVcsTUFBSyxVQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdEO0FBQUEsSUFDeEQsdUJBQUMsWUFDQyxjQUFXLG1CQUNYLFNBQVMsTUFBTTtBQUNiLFlBQU1BLFVBQ0pDLFNBQVNDLGVBQWUsVUFBVSxFQUNsQ0M7QUFDRkosc0JBQWdCQyxPQUFPO0FBQUEsSUFDekIsR0FBRSxtQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLFlBQ0MsU0FBUyxZQUFZO0FBRW5CTCxlQUFTLEVBQUU7QUFFWCxZQUFNTixVQUFVO0FBQUEsSUFDbEIsR0FBRSwyQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUdBLHVCQUFDLE9BQ0MsaUNBQUMsT0FBRSxjQUFXLGVBQWM7QUFBQTtBQUFBLE1BQXlCTztBQUFBQSxNQUFRO0FBQUEsU0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFFBQUcsY0FBVyxrQkFDWkYsZ0JBQU1VLElBQUksQ0FBQ0MsTUFBTUMsVUFDaEIsdUJBQUMsT0FBYyxjQUFXLFFBQ3ZCRCxrQkFES0MsT0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsQ0FDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1Q0E7QUFFSjtBQUFDYixHQTVEdUJELGVBQWE7QUFBQWUsS0FBYmY7QUFBYSxJQUFBZTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJhZGRXb3JkIiwiY2xlYXJVc2VyIiwiZ2V0V29yZHMiLCJnZXRMb2dpbkNvb2tpZSIsIkZpcmVzdG9yZURlbW8iLCJfcyIsIndvcmRzIiwic2V0V29yZHMiLCJVU0VSX0lEIiwidGhlbiIsImRhdGEiLCJhZGRGYXZvcml0ZVdvcmQiLCJuZXdXb3JkIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInZhbHVlIiwibWFwIiwid29yZCIsImluZGV4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaXJlc3RvcmVEZW1vLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBhZGRXb3JkLCBjbGVhclVzZXIsIGdldFdvcmRzIH0gZnJvbSBcIi4uL3V0aWxzL2FwaVwiO1xuaW1wb3J0IHsgZ2V0TG9naW5Db29raWUgfSBmcm9tIFwiLi4vdXRpbHMvY29va2llXCI7XG4vKipcbiAqIEZvciBhZGRpbmcgYW5kIHJlbW92aW5nIGZhdm9yaXRlIHdvcmRzIGZyb20gdGhlIGZpcmVzdG9yZSBkYXRhYmFzZS5cbiAqXG4gKiBAcmV0dXJucyBNYWluIHBhZ2UgdGhhdCBkZWFscyB3aXRoIHRoZSBmaXJlIHN0b3JlIGRhdGFiYXNlXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZpcmVzdG9yZURlbW8oKSB7XG4gIGNvbnN0IFt3b3Jkcywgc2V0V29yZHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcblxuICBjb25zdCBVU0VSX0lEID0gZ2V0TG9naW5Db29raWUoKSB8fCBcIlwiO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZ2V0V29yZHMoKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBzZXRXb3JkcyhkYXRhLndvcmRzKTtcbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGFkZEZhdm9yaXRlV29yZCA9IGFzeW5jIChuZXdXb3JkOiBzdHJpbmcpID0+IHtcbiAgICAvLyAtIHVwZGF0ZSB0aGUgY2xpZW50IHdvcmRzIHN0YXRlIHRvIGluY2x1ZGUgdGhlIG5ldyB3b3JkXG4gICAgc2V0V29yZHMoWy4uLndvcmRzLCBuZXdXb3JkXSk7XG4gICAgLy8gLSBxdWVyeSB0aGUgYmFja2VuZCB0byBhZGQgdGhlIG5ldyB3b3JkIHRvIHRoZSBkYXRhYmFzZVxuICAgIGF3YWl0IGFkZFdvcmQobmV3V29yZCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpcmVzdG9yZS1kZW1vXCI+XG4gICAgICA8aDI+RmlyZXN0b3JlIERlbW88L2gyPlxuICAgICAgey8qIGFkZGluZyBuZXcgd29yZHM6ICovfVxuICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctd29yZFwiPkFkZCBhIGZhdm9yaXRlIHdvcmQ6PC9sYWJlbD5cbiAgICAgIDxpbnB1dCBhcmlhLWxhYmVsPVwid29yZC1pbnB1dFwiIGlkPVwibmV3LXdvcmRcIiB0eXBlPVwidGV4dFwiIC8+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIGFyaWEtbGFiZWw9XCJhZGQtd29yZC1idXR0b25cIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgY29uc3QgbmV3V29yZCA9IChcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibmV3LXdvcmRcIikgYXMgSFRNTElucHV0RWxlbWVudFxuICAgICAgICAgICkudmFsdWU7XG4gICAgICAgICAgYWRkRmF2b3JpdGVXb3JkKG5ld1dvcmQpO1xuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICBBZGRcbiAgICAgIDwvYnV0dG9uPlxuICAgICAgey8qIENsZWFyIHdvcmRzIGJ1dHRvbiAqL31cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgIC8vIC0gcXVlcnkgdGhlIGJhY2tlbmQgdG8gY2xlYXIgdGhlIHVzZXIncyB3b3Jkc1xuICAgICAgICAgIHNldFdvcmRzKFtdKTtcbiAgICAgICAgICAvLyAtIGNsZWFyIHRoZSB1c2VyJ3Mgd29yZHMgaW4gdGhlIGRhdGFiYXNlXG4gICAgICAgICAgYXdhaXQgY2xlYXJVc2VyKCk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIENsZWFyIHdvcmRzXG4gICAgICA8L2J1dHRvbj5cblxuICAgICAgey8qIGxpc3Qgb2Ygd29yZHMgZnJvbSBkYjogKi99XG4gICAgICA8cD5cbiAgICAgICAgPGkgYXJpYS1sYWJlbD1cInVzZXItaGVhZGVyXCI+RmF2b3JpdGUgd29yZHMgZm9yIHVzZXIge1VTRVJfSUR9OjwvaT5cbiAgICAgIDwvcD5cbiAgICAgIDx1bCBhcmlhLWxhYmVsPVwiZmF2b3JpdGUtd29yZHNcIj5cbiAgICAgICAge3dvcmRzLm1hcCgod29yZCwgaW5kZXgpID0+IChcbiAgICAgICAgICA8cCBrZXk9e2luZGV4fSBhcmlhLWxhYmVsPVwid29yZFwiPlxuICAgICAgICAgICAge3dvcmR9XG4gICAgICAgICAgPC9wPlxuICAgICAgICApKX1cbiAgICAgIDwvdWw+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9oYXBweTJuYS9EZXNrdG9wL21hcHMtbXpoZW5nMzctYXN1bjU5L2NsaWVudC9zcmMvY29tcG9uZW50cy9GaXJlc3RvcmVEZW1vLnRzeCJ9