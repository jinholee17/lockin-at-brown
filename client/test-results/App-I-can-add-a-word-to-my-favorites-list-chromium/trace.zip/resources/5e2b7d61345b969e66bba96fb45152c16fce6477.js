import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZVMIEU5R.js?v=4ea8f8d0";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=4ea8f8d0";
export default require_react();
//# sourceMappingURL=react.js.map
