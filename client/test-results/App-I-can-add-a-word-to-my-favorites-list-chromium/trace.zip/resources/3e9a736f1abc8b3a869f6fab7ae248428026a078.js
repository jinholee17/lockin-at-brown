import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/AuthRoute.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/AuthRoute.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4ea8f8d0"; const useState = __vite__cjsImport3_react["useState"];
import { getLoginCookie } from "/src/utils/cookie.ts";
import LoginLogout from "/src/components/auth/LoginLogout.tsx";
function AuthRoute(props) {
  _s();
  const [loggedIn, setLogin] = useState(false);
  if (!loggedIn && getLoginCookie() !== void 0) {
    setLogin(true);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(LoginLogout, { loggedIn, setLogin }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/AuthRoute.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    loggedIn ? props.gatedContent : null
  ] }, void 0, true, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/AuthRoute.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
}
_s(AuthRoute, "DpWSO8fnwBHZhhWwX5EqLBZmdOA=");
_c = AuthRoute;
export default AuthRoute;
var _c;
$RefreshReg$(_c, "AuthRoute");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/AuthRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6QkosU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUFzQjtBQUMvQixPQUFPQyxpQkFBaUI7QUFjeEIsU0FBU0MsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUN4QyxRQUFNLENBQUNDLFVBQVVDLFFBQVEsSUFBSVAsU0FBUyxLQUFLO0FBRzNDLE1BQUksQ0FBQ00sWUFBWUwsZUFBZSxNQUFNTyxRQUFXO0FBQy9DRCxhQUFTLElBQUk7QUFBQSxFQUNmO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLGVBQVksVUFBb0IsWUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRDtBQUFBLElBRW5ERCxXQUFXRixNQUFNSyxlQUFlO0FBQUEsT0FIbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBQ0osR0FmUUYsV0FBUztBQUFBTyxLQUFUUDtBQWlCVCxlQUFlQTtBQUFVLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImdldExvZ2luQ29va2llIiwiTG9naW5Mb2dvdXQiLCJBdXRoUm91dGUiLCJwcm9wcyIsIl9zIiwibG9nZ2VkSW4iLCJzZXRMb2dpbiIsInVuZGVmaW5lZCIsImdhdGVkQ29udGVudCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXV0aFJvdXRlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZ2V0TG9naW5Db29raWUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvY29va2llXCI7XG5pbXBvcnQgTG9naW5Mb2dvdXQgZnJvbSBcIi4vTG9naW5Mb2dvdXRcIjtcblxuLyoqXG4gKiBpbnRlcmZhY2UgdG8gbWFuYWdlIGF1dGhlbnRpY2F0aW9uIGNvbnRlbnRcbiAqL1xuaW50ZXJmYWNlIEF1dGhSb3V0ZVByb3BzIHtcbiAgZ2F0ZWRDb250ZW50OiBSZWFjdC5SZWFjdE5vZGU7XG59XG4vKipcbiAqIENvbXBvbmVudCB0byByZW5kZXIgYXV0aGVudGljYXRpb24gY29tcG9uZW50IGZvciBmaXJlYmFzZVxuICpcbiAqIEBwYXJhbSBwcm9wcyBDb21wb25lbnQgZm9yIGhhbmRsaW5nIGF1dGhlbnRpY2F0aW9uIGxvZ2ljLlxuICogQHJldHVybiBjb21wb25lbnQgZm9yIGxvZ2dpbiBpbiBhbmQgbG9nZ2luIG91dFxuICovXG5mdW5jdGlvbiBBdXRoUm91dGUocHJvcHM6IEF1dGhSb3V0ZVByb3BzKSB7XG4gIGNvbnN0IFtsb2dnZWRJbiwgc2V0TG9naW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIFNLSVAgVEhFIExPR0lOIEJVVFRPTiBJRiBZT1UgSEFWRSBBTFJFQURZIExPR0dFRCBJTi5cbiAgaWYgKCFsb2dnZWRJbiAmJiBnZXRMb2dpbkNvb2tpZSgpICE9PSB1bmRlZmluZWQpIHtcbiAgICBzZXRMb2dpbih0cnVlKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxMb2dpbkxvZ291dCBsb2dnZWRJbj17bG9nZ2VkSW59IHNldExvZ2luPXtzZXRMb2dpbn0gLz5cblxuICAgICAge2xvZ2dlZEluID8gcHJvcHMuZ2F0ZWRDb250ZW50IDogbnVsbH1cbiAgICA8Lz5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXV0aFJvdXRlO1xuIl0sImZpbGUiOiIvVXNlcnMvaGFwcHkybmEvRGVza3RvcC9tYXBzLW16aGVuZzM3LWFzdW41OS9jbGllbnQvc3JjL2NvbXBvbmVudHMvYXV0aC9BdXRoUm91dGUudHN4In0=