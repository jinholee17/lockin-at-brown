import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Mapbox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/node_modules/mapbox-gl/dist/mapbox-gl.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=4ea8f8d0"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import Map, { Layer, Source, Marker } from "/node_modules/.vite/deps/react-map-gl.js?v=4ea8f8d0";
import { geoLayer, overlayData } from "/src/utils/overlay.ts";
import { geoLayerFilter, overlayDataFilter } from "/src/utils/overlayFilter.ts";
import { addPin, getPins, clearPins } from "/src/utils/api.ts";
const MAPBOX_API_KEY = process.env.MAPBOX_TOKEN;
if (!MAPBOX_API_KEY) {
  console.error("Mapbox API key not found. Please add it to your .env file.");
}
const ProvidenceLatLong = {
  lat: 41.824,
  long: -71.4128
};
const initialZoom = 10;
export default function Mapbox() {
  _s();
  const [pins, setPins] = useState([]);
  useEffect(() => {
    getPins().then((data) => {
      console.log("Fetched pins:", data);
      setPins(data.pins);
    });
    console.log(pins);
  }, []);
  const addingPin = async (newPin) => {
    setPins([...pins, newPin]);
    await addPin(newPin);
  };
  function onMapClick(e) {
    addingPin("lat:" + e.lngLat.lat.toString() + ", long:" + e.lngLat.lng.toString());
  }
  const [viewState, setViewState] = useState({
    latitude: ProvidenceLatLong.lat,
    longitude: ProvidenceLatLong.long,
    zoom: initialZoom
  });
  const [overlay, setOverlay] = useState(void 0);
  useEffect(() => {
    overlayData().then((data) => {
      setOverlay(data);
    });
  }, []);
  const [commandString, setCommandString] = useState("");
  const [useFilter, setUseFilter] = useState(false);
  const [overlayFilter, setOverlayFilter] = useState(void 0);
  function handleSubmit(commandString2) {
    setUseFilter(true);
    overlayDataFilter(commandString2).then((data) => {
      setOverlayFilter(data);
    });
    const inputField = document.getElementById("input-field");
    if (inputField) {
      inputField.value = "";
    }
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "map", children: [
    /* @__PURE__ */ jsxDEV("input", { id: "input-field", "aria-label": "area description search textbox", className: "area-input", placeholder: "Enter area description search here", onChange: (ev) => setCommandString(ev.target.value) }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "aria-lable": "Submit", "aria-description": "Press enter key or click submit button to process command", className: "submit-btn", onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "aria-lable": "Clear Search", "aria-description": "Press enter key or click submit button to clear current search", className: "submit-btn", onClick: () => {
      setOverlayFilter(void 0);
      setUseFilter(false);
    }, children: "Clear Search" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Map, { mapboxAccessToken: MAPBOX_API_KEY, ...viewState, style: {
      width: window.innerWidth,
      height: window.innerHeight
    }, mapStyle: "mapbox://styles/mapbox/streets-v12", onMove: (ev) => setViewState(ev.viewState), onClick: (ev) => onMapClick(ev), children: [
      /* @__PURE__ */ jsxDEV(Source, { id: "geo_data", type: "geojson", data: overlay, children: /* @__PURE__ */ jsxDEV(Layer, { id: geoLayer.id, type: geoLayer.type, paint: geoLayer.paint }, void 0, false, {
        fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
        lineNumber: 115,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      useFilter && /* @__PURE__ */ jsxDEV(Source, { id: "geo_data_filter", type: "geojson", data: overlayFilter, "arai-label": "filter-overlay", children: /* @__PURE__ */ jsxDEV(Layer, { ...geoLayerFilter }, void 0, false, {
        fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
        lineNumber: 119,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
        lineNumber: 118,
        columnNumber: 23
      }, this),
      pins.map((pin, index) => {
        const [lat, long] = pin.split(" ");
        const latitude = parseFloat(lat.split(":")[1]);
        const longitude = parseFloat(long.split(":")[1]);
        return /* @__PURE__ */ jsxDEV(Marker, { latitude, longitude, children: /* @__PURE__ */ jsxDEV("div", { style: {
          fontSize: 20
        }, children: "📍" }, void 0, false, {
          fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
          lineNumber: 129,
          columnNumber: 15
        }, this) }, index, false, {
          fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
          lineNumber: 127,
          columnNumber: 16
        }, this);
      })
    ] }, void 0, true, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: async () => {
          setPins([]);
          await clearPins();
        },
        children: "Clear Pins"
      },
      void 0,
      false,
      {
        fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
        lineNumber: 136,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx",
    lineNumber: 99,
    columnNumber: 10
  }, this);
}
_s(Mapbox, "QfNsBOTfNcR15oR7iVLqZirLGr0=");
_c = Mapbox;
var _c;
$RefreshReg$(_c, "Mapbox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/Mapbox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0hNOzs7Ozs7Ozs7Ozs7Ozs7O0FBcEhOLE9BQU87QUFDUCxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsT0FDTEMsT0FFQUMsUUFFQUMsY0FDSztBQUNQLFNBQVNDLFVBQVVDLG1CQUFtQjtBQUN0QyxTQUFTQyxnQkFBZ0JDLHlCQUF5QjtBQUNsRCxTQUFTQyxRQUFRQyxTQUFTQyxpQkFBaUI7QUFLM0MsTUFBTUMsaUJBQWlCQyxRQUFRQyxJQUFJQztBQUNuQyxJQUFJLENBQUNILGdCQUFnQjtBQUNuQkksVUFBUUMsTUFBTSw0REFBNEQ7QUFDNUU7QUFPQSxNQUFNQyxvQkFBNkI7QUFBQSxFQUNqQ0MsS0FBSztBQUFBLEVBQ0xDLE1BQU07QUFDUjtBQUNBLE1BQU1DLGNBQWM7QUFRcEIsd0JBQXdCQyxTQUFTO0FBQUFDLEtBQUE7QUFFL0IsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUl6QixTQUFtQixFQUFFO0FBQzdDRCxZQUFVLE1BQU07QUFDZFcsWUFBUSxFQUFFZ0IsS0FBTUMsVUFBUztBQUN2QlgsY0FBUVksSUFBSSxpQkFBaUJELElBQUk7QUFDakNGLGNBQVFFLEtBQUtILElBQUk7QUFBQSxJQUNuQixDQUFDO0FBQ0RSLFlBQVFZLElBQUlKLElBQUk7QUFBQSxFQUNsQixHQUFHLEVBQUU7QUFFTCxRQUFNSyxZQUFZLE9BQU9DLFdBQW1CO0FBRTFDTCxZQUFRLENBQUMsR0FBR0QsTUFBTU0sTUFBTSxDQUFDO0FBRXpCLFVBQU1yQixPQUFPcUIsTUFBTTtBQUFBLEVBQ3JCO0FBT0EsV0FBU0MsV0FBV0MsR0FBdUI7QUFDekNILGNBQ0UsU0FBU0csRUFBRUMsT0FBT2QsSUFBSWUsU0FBUyxJQUFJLFlBQVlGLEVBQUVDLE9BQU9FLElBQUlELFNBQVMsQ0FDdkU7QUFBQSxFQUNGO0FBR0EsUUFBTSxDQUFDRSxXQUFXQyxZQUFZLElBQUlyQyxTQUFTO0FBQUEsSUFDekNzQyxVQUFVcEIsa0JBQWtCQztBQUFBQSxJQUM1Qm9CLFdBQVdyQixrQkFBa0JFO0FBQUFBLElBQzdCb0IsTUFBTW5CO0FBQUFBLEVBQ1IsQ0FBQztBQUdELFFBQU0sQ0FBQ29CLFNBQVNDLFVBQVUsSUFBSTFDLFNBQzVCMkMsTUFDRjtBQUVBNUMsWUFBVSxNQUFNO0FBQ2RPLGdCQUFZLEVBQUVvQixLQUFNQyxVQUFTO0FBQzNCZSxpQkFBV2YsSUFBSTtBQUFBLElBQ2pCLENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRTtBQUdMLFFBQU0sQ0FBQ2lCLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUM4QyxXQUFXQyxZQUFZLElBQUkvQyxTQUFrQixLQUFLO0FBRXpELFFBQU0sQ0FBQ2dELGVBQWVDLGdCQUFnQixJQUFJakQsU0FFeEMyQyxNQUFTO0FBU1gsV0FBU08sYUFBYU4sZ0JBQXVCO0FBQzNDRyxpQkFBYSxJQUFJO0FBQ2pCdkMsc0JBQWtCb0MsY0FBYSxFQUFFbEIsS0FBTUMsVUFBUztBQUM5Q3NCLHVCQUFpQnRCLElBQUk7QUFBQSxJQUN2QixDQUFDO0FBQ0QsVUFBTXdCLGFBQWFDLFNBQVNDLGVBQzFCLGFBQ0Y7QUFDQSxRQUFJRixZQUFZO0FBQ2RBLGlCQUFXRyxRQUFRO0FBQUEsSUFDckI7QUFDQVQscUJBQWlCLEVBQUU7QUFBQSxFQUNyQjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQkFBQyxXQUNDLElBQUcsZUFDSCxjQUFXLG1DQUNYLFdBQVUsY0FDVixhQUFZLHNDQUNaLFVBQVdVLFFBQU9WLGlCQUFpQlUsR0FBR0MsT0FBT0YsS0FBSyxLQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUM7QUFBQSxJQUNELHVCQUFDLFlBQ0MsY0FBVyxVQUNYLG9CQUFpQiw2REFDakIsV0FBVSxjQUNWLFNBQVMsTUFBTUosYUFBYU4sYUFBYSxHQUFFLHNCQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0MsY0FBVyxnQkFDWCxvQkFBaUIsa0VBQ2pCLFdBQVUsY0FDVixTQUFTLE1BQU07QUFDYkssdUJBQWlCTixNQUFTO0FBQzFCSSxtQkFBYSxLQUFLO0FBQUEsSUFDcEIsR0FBRSw0QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLE9BQ0MsbUJBQW1CbkMsZ0JBQ25CLEdBQUl3QixXQUNKLE9BQU87QUFBQSxNQUFFcUIsT0FBT0MsT0FBT0M7QUFBQUEsTUFBWUMsUUFBUUYsT0FBT0c7QUFBQUEsSUFBWSxHQUM5RCxVQUFVLHNDQUNWLFFBQVEsQ0FBQ04sT0FBNkJsQixhQUFha0IsR0FBR25CLFNBQVMsR0FDL0QsU0FBUyxDQUFDbUIsT0FBMkJ4QixXQUFXd0IsRUFBRSxHQUVsRDtBQUFBLDZCQUFDLFVBQU8sSUFBRyxZQUFXLE1BQUssV0FBVSxNQUFNZCxTQUN6QyxpQ0FBQyxTQUFNLElBQUlwQyxTQUFTeUQsSUFBSSxNQUFNekQsU0FBUzBELE1BQU0sT0FBTzFELFNBQVMyRCxTQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FLEtBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUNsQixhQUNDLHVCQUFDLFVBQ0MsSUFBRyxtQkFDSCxNQUFLLFdBQ0wsTUFBTUUsZUFDTixjQUFXLGtCQUVYLGlDQUFDLFNBQU0sR0FBSXpDLGtCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEIsS0FONUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFHRGlCLEtBQUt5QyxJQUFJLENBQUNDLEtBQUtDLFVBQVU7QUFFeEIsY0FBTSxDQUFDaEQsS0FBS0MsSUFBSSxJQUFJOEMsSUFBSUUsTUFBTSxHQUFHO0FBQ2pDLGNBQU05QixXQUFXK0IsV0FBV2xELElBQUlpRCxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDN0MsY0FBTTdCLFlBQVk4QixXQUFXakQsS0FBS2dELE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvQyxlQUNFLHVCQUFDLFVBQW1CLFVBQW9CLFdBRXRDLGlDQUFDLFNBQUksT0FBTztBQUFBLFVBQUVFLFVBQVU7QUFBQSxRQUFHLEdBQUcsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FGckJILE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFFSixDQUFDO0FBQUEsU0FsQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsWUFBWTtBQUVuQjFDLGtCQUFRLEVBQUU7QUFFVixnQkFBTWQsVUFBVTtBQUFBLFFBQ2xCO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQTtBQUFBLE9BMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyRUE7QUFFSjtBQUFDWSxHQTFKdUJELFFBQU07QUFBQWlELEtBQU5qRDtBQUFNLElBQUFpRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJNYXAiLCJMYXllciIsIlNvdXJjZSIsIk1hcmtlciIsImdlb0xheWVyIiwib3ZlcmxheURhdGEiLCJnZW9MYXllckZpbHRlciIsIm92ZXJsYXlEYXRhRmlsdGVyIiwiYWRkUGluIiwiZ2V0UGlucyIsImNsZWFyUGlucyIsIk1BUEJPWF9BUElfS0VZIiwicHJvY2VzcyIsImVudiIsIk1BUEJPWF9UT0tFTiIsImNvbnNvbGUiLCJlcnJvciIsIlByb3ZpZGVuY2VMYXRMb25nIiwibGF0IiwibG9uZyIsImluaXRpYWxab29tIiwiTWFwYm94IiwiX3MiLCJwaW5zIiwic2V0UGlucyIsInRoZW4iLCJkYXRhIiwibG9nIiwiYWRkaW5nUGluIiwibmV3UGluIiwib25NYXBDbGljayIsImUiLCJsbmdMYXQiLCJ0b1N0cmluZyIsImxuZyIsInZpZXdTdGF0ZSIsInNldFZpZXdTdGF0ZSIsImxhdGl0dWRlIiwibG9uZ2l0dWRlIiwiem9vbSIsIm92ZXJsYXkiLCJzZXRPdmVybGF5IiwidW5kZWZpbmVkIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJ1c2VGaWx0ZXIiLCJzZXRVc2VGaWx0ZXIiLCJvdmVybGF5RmlsdGVyIiwic2V0T3ZlcmxheUZpbHRlciIsImhhbmRsZVN1Ym1pdCIsImlucHV0RmllbGQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwidmFsdWUiLCJldiIsInRhcmdldCIsIndpZHRoIiwid2luZG93IiwiaW5uZXJXaWR0aCIsImhlaWdodCIsImlubmVySGVpZ2h0IiwiaWQiLCJ0eXBlIiwicGFpbnQiLCJtYXAiLCJwaW4iLCJpbmRleCIsInNwbGl0IiwicGFyc2VGbG9hdCIsImZvbnRTaXplIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNYXBib3gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIm1hcGJveC1nbC9kaXN0L21hcGJveC1nbC5jc3NcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBNYXAsIHtcbiAgTGF5ZXIsXG4gIE1hcExheWVyTW91c2VFdmVudCxcbiAgU291cmNlLFxuICBWaWV3U3RhdGVDaGFuZ2VFdmVudCxcbiAgTWFya2VyLFxufSBmcm9tIFwicmVhY3QtbWFwLWdsXCI7XG5pbXBvcnQgeyBnZW9MYXllciwgb3ZlcmxheURhdGEgfSBmcm9tIFwiLi4vdXRpbHMvb3ZlcmxheVwiO1xuaW1wb3J0IHsgZ2VvTGF5ZXJGaWx0ZXIsIG92ZXJsYXlEYXRhRmlsdGVyIH0gZnJvbSBcIi4uL3V0aWxzL292ZXJsYXlGaWx0ZXJcIjtcbmltcG9ydCB7IGFkZFBpbiwgZ2V0UGlucywgY2xlYXJQaW5zIH0gZnJvbSBcIi4uL3V0aWxzL2FwaVwiO1xuXG4vKipcbiAqIEVuc3VyZSB0aGF0IE1hcGJveCBBUEkga2V5IGlzIHRoZXJlXG4gKi9cbmNvbnN0IE1BUEJPWF9BUElfS0VZID0gcHJvY2Vzcy5lbnYuTUFQQk9YX1RPS0VOO1xuaWYgKCFNQVBCT1hfQVBJX0tFWSkge1xuICBjb25zb2xlLmVycm9yKFwiTWFwYm94IEFQSSBrZXkgbm90IGZvdW5kLiBQbGVhc2UgYWRkIGl0IHRvIHlvdXIgLmVudiBmaWxlLlwiKTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBMYXRMb25nIHtcbiAgbGF0OiBudW1iZXI7XG4gIGxvbmc6IG51bWJlcjtcbn1cblxuY29uc3QgUHJvdmlkZW5jZUxhdExvbmc6IExhdExvbmcgPSB7XG4gIGxhdDogNDEuODI0LFxuICBsb25nOiAtNzEuNDEyOCxcbn07XG5jb25zdCBpbml0aWFsWm9vbSA9IDEwO1xuXG4vKipcbiAqIE1haW4gZnVuY3Rpb24gdGhhdCBoYW5kbGVzIGFsbCB0aGUgbWFwIGJveCBsb2dpY1xuICogSXQgZGVhbHMgd2l0aCBzdG9yaW5nIHBpbnMgYW5kIGhpZ2hsaWdodGluZyB2YXJpb3VzIGRhdGFcbiAqXG4gKiBAcmV0dXJucyB0aGUgbWFwYm94IHJlbmRlclxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYXBib3goKSB7XG4gIC8vIEFkZGluZyBwaW4gdG8gZmlyZXN0b3JlXG4gIGNvbnN0IFtwaW5zLCBzZXRQaW5zXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZ2V0UGlucygpLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKFwiRmV0Y2hlZCBwaW5zOlwiLCBkYXRhKTtcbiAgICAgIHNldFBpbnMoZGF0YS5waW5zKTtcbiAgICB9KTtcbiAgICBjb25zb2xlLmxvZyhwaW5zKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGFkZGluZ1BpbiA9IGFzeW5jIChuZXdQaW46IHN0cmluZykgPT4ge1xuICAgIC8vIC0gdXBkYXRlIHRoZSBjbGllbnQgd29yZHMgc3RhdGUgdG8gaW5jbHVkZSB0aGUgbmV3IHdvcmRcbiAgICBzZXRQaW5zKFsuLi5waW5zLCBuZXdQaW5dKTtcbiAgICAvLyAtIHF1ZXJ5IHRoZSBiYWNrZW5kIHRvIGFkZCB0aGUgbmV3IHdvcmQgdG8gdGhlIGRhdGFiYXNlXG4gICAgYXdhaXQgYWRkUGluKG5ld1Bpbik7XG4gIH07XG5cbiAgLyoqXG4gICAqIFRvIGVuc3VyZSB0aGF0IHdoZW5ldmVyIGEgY2xpY2sgaGFwcGVucywgYSBwaW4gd2lsbCBiZSBhZGRlZFxuICAgKlxuICAgKiBAcGFyYW0gZSB0aGUgY2xpY2tpbmcgZXZlbnRcbiAgICovXG4gIGZ1bmN0aW9uIG9uTWFwQ2xpY2soZTogTWFwTGF5ZXJNb3VzZUV2ZW50KSB7XG4gICAgYWRkaW5nUGluKFxuICAgICAgXCJsYXQ6XCIgKyBlLmxuZ0xhdC5sYXQudG9TdHJpbmcoKSArIFwiLCBsb25nOlwiICsgZS5sbmdMYXQubG5nLnRvU3RyaW5nKClcbiAgICApO1xuICB9XG5cbiAgLy8gem9vbSBhbmQgbW92ZSBhcm91bmQgZm9yIG1hcFxuICBjb25zdCBbdmlld1N0YXRlLCBzZXRWaWV3U3RhdGVdID0gdXNlU3RhdGUoe1xuICAgIGxhdGl0dWRlOiBQcm92aWRlbmNlTGF0TG9uZy5sYXQsXG4gICAgbG9uZ2l0dWRlOiBQcm92aWRlbmNlTGF0TG9uZy5sb25nLFxuICAgIHpvb206IGluaXRpYWxab29tLFxuICB9KTtcblxuICAvLyByZWQtbGluZSBkYXRhIGRlZmF1bHQgb3ZlcmxheVxuICBjb25zdCBbb3ZlcmxheSwgc2V0T3ZlcmxheV0gPSB1c2VTdGF0ZTxHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uIHwgdW5kZWZpbmVkPihcbiAgICB1bmRlZmluZWRcbiAgKTtcbiAgLy8gQWRkcyB0aGUgb3ZlcmxheSB0byB0aGUgbWFwIChyZWRsaW5pbmcpXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgb3ZlcmxheURhdGEoKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBzZXRPdmVybGF5KGRhdGEpO1xuICAgIH0pO1xuICB9LCBbXSk7XG5cbiAgLy8gc2VhcmNoIHdpdGggYXJlYS1kZXNjcmlwdGlvbiBmaWx0ZXIsIGFkZHMgYW5vdGhlciBvdmVybGF5XG4gIGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IFt1c2VGaWx0ZXIsIHNldFVzZUZpbHRlcl0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIC8vIEFkZHMgdGhlIG92ZXJsYXkgdG8gdGhlIG1hcCAoc2VhcmNoIGRlc2NyaXB0aW9uKVxuICBjb25zdCBbb3ZlcmxheUZpbHRlciwgc2V0T3ZlcmxheUZpbHRlcl0gPSB1c2VTdGF0ZTxcbiAgICBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uIHwgdW5kZWZpbmVkXG4gID4odW5kZWZpbmVkKTtcblxuICAvKipcbiAgICogRGVhbHMgd2l0aCB0YWtpbmcgaW5hIHVzZXIgZGVzY3JpcHRpb250IHRoYXQgd2lsbCBiZSB1dGlsemllZCB0b1xuICAgKiBoaWdobGlnaHQgYXJlYXMgd2l0aCB0aGUgcHJvdmlkZWQgZGVzY3JpcHRpb25cbiAgICogQ2xlYXJzIHNlYXJjaCBpbnB1dCBhcmVhIGFmdGVyIGNsaWNraW5nIHN1Ym1pdFxuICAgKlxuICAgKiBAcGFyYW0gY29tbWFuZFN0cmluZ1xuICAgKi9cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIHNldFVzZUZpbHRlcih0cnVlKTtcbiAgICBvdmVybGF5RGF0YUZpbHRlcihjb21tYW5kU3RyaW5nKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBzZXRPdmVybGF5RmlsdGVyKGRhdGEpO1xuICAgIH0pO1xuICAgIGNvbnN0IGlucHV0RmllbGQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcbiAgICAgIFwiaW5wdXQtZmllbGRcIlxuICAgICkgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICBpZiAoaW5wdXRGaWVsZCkge1xuICAgICAgaW5wdXRGaWVsZC52YWx1ZSA9IFwiXCI7XG4gICAgfVxuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwXCI+XG4gICAgICA8aW5wdXRcbiAgICAgICAgaWQ9XCJpbnB1dC1maWVsZFwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJhcmVhIGRlc2NyaXB0aW9uIHNlYXJjaCB0ZXh0Ym94XCJcbiAgICAgICAgY2xhc3NOYW1lPVwiYXJlYS1pbnB1dFwiXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYXJlYSBkZXNjcmlwdGlvbiBzZWFyY2ggaGVyZVwiXG4gICAgICAgIG9uQ2hhbmdlPXsoZXYpID0+IHNldENvbW1hbmRTdHJpbmcoZXYudGFyZ2V0LnZhbHVlKX1cbiAgICAgID48L2lucHV0PlxuICAgICAgPGJ1dHRvblxuICAgICAgICBhcmlhLWxhYmxlPVwiU3VibWl0XCJcbiAgICAgICAgYXJpYS1kZXNjcmlwdGlvbj1cIlByZXNzIGVudGVyIGtleSBvciBjbGljayBzdWJtaXQgYnV0dG9uIHRvIHByb2Nlc3MgY29tbWFuZFwiXG4gICAgICAgIGNsYXNzTmFtZT1cInN1Ym1pdC1idG5cIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9XG4gICAgICA+XG4gICAgICAgIFN1Ym1pdFxuICAgICAgPC9idXR0b24+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIGFyaWEtbGFibGU9XCJDbGVhciBTZWFyY2hcIlxuICAgICAgICBhcmlhLWRlc2NyaXB0aW9uPVwiUHJlc3MgZW50ZXIga2V5IG9yIGNsaWNrIHN1Ym1pdCBidXR0b24gdG8gY2xlYXIgY3VycmVudCBzZWFyY2hcIlxuICAgICAgICBjbGFzc05hbWU9XCJzdWJtaXQtYnRuXCJcbiAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgIHNldE92ZXJsYXlGaWx0ZXIodW5kZWZpbmVkKTtcbiAgICAgICAgICBzZXRVc2VGaWx0ZXIoZmFsc2UpO1xuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICBDbGVhciBTZWFyY2hcbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPE1hcFxuICAgICAgICBtYXBib3hBY2Nlc3NUb2tlbj17TUFQQk9YX0FQSV9LRVl9XG4gICAgICAgIHsuLi52aWV3U3RhdGV9XG4gICAgICAgIHN0eWxlPXt7IHdpZHRoOiB3aW5kb3cuaW5uZXJXaWR0aCwgaGVpZ2h0OiB3aW5kb3cuaW5uZXJIZWlnaHQgfX1cbiAgICAgICAgbWFwU3R5bGU9e1wibWFwYm94Oi8vc3R5bGVzL21hcGJveC9zdHJlZXRzLXYxMlwifVxuICAgICAgICBvbk1vdmU9eyhldjogVmlld1N0YXRlQ2hhbmdlRXZlbnQpID0+IHNldFZpZXdTdGF0ZShldi52aWV3U3RhdGUpfVxuICAgICAgICBvbkNsaWNrPXsoZXY6IE1hcExheWVyTW91c2VFdmVudCkgPT4gb25NYXBDbGljayhldil9XG4gICAgICA+XG4gICAgICAgIDxTb3VyY2UgaWQ9XCJnZW9fZGF0YVwiIHR5cGU9XCJnZW9qc29uXCIgZGF0YT17b3ZlcmxheX0+XG4gICAgICAgICAgPExheWVyIGlkPXtnZW9MYXllci5pZH0gdHlwZT17Z2VvTGF5ZXIudHlwZX0gcGFpbnQ9e2dlb0xheWVyLnBhaW50fSAvPlxuICAgICAgICA8L1NvdXJjZT5cblxuICAgICAgICB7dXNlRmlsdGVyICYmIChcbiAgICAgICAgICA8U291cmNlXG4gICAgICAgICAgICBpZD1cImdlb19kYXRhX2ZpbHRlclwiXG4gICAgICAgICAgICB0eXBlPVwiZ2VvanNvblwiXG4gICAgICAgICAgICBkYXRhPXtvdmVybGF5RmlsdGVyfVxuICAgICAgICAgICAgYXJhaS1sYWJlbD1cImZpbHRlci1vdmVybGF5XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8TGF5ZXIgey4uLmdlb0xheWVyRmlsdGVyfSAvPlxuICAgICAgICAgIDwvU291cmNlPlxuICAgICAgICApfVxuXG4gICAgICAgIHtwaW5zLm1hcCgocGluLCBpbmRleCkgPT4ge1xuICAgICAgICAgIC8vIFNwbGl0IHRoZSBwaW4gc3RyaW5nIGludG8gbGF0aXR1ZGUgYW5kIGxvbmdpdHVkZVxuICAgICAgICAgIGNvbnN0IFtsYXQsIGxvbmddID0gcGluLnNwbGl0KFwiIFwiKTtcbiAgICAgICAgICBjb25zdCBsYXRpdHVkZSA9IHBhcnNlRmxvYXQobGF0LnNwbGl0KFwiOlwiKVsxXSk7XG4gICAgICAgICAgY29uc3QgbG9uZ2l0dWRlID0gcGFyc2VGbG9hdChsb25nLnNwbGl0KFwiOlwiKVsxXSk7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxNYXJrZXIga2V5PXtpbmRleH0gbGF0aXR1ZGU9e2xhdGl0dWRlfSBsb25naXR1ZGU9e2xvbmdpdHVkZX0+XG4gICAgICAgICAgICAgIHsvKiBNYXJrZXIgY29udGVudCAqL31cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogMjAgfX0+8J+TjTwvZGl2PlxuICAgICAgICAgICAgPC9NYXJrZXI+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L01hcD5cblxuICAgICAgPGJ1dHRvblxuICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgLy8gLSBxdWVyeSB0aGUgYmFja2VuZCB0byBjbGVhciB0aGUgdXNlcidzIHdvcmRzXG4gICAgICAgICAgc2V0UGlucyhbXSk7IC8vIEFzc3VtaW5nIHNldFBpbnMgaXMgYSBmdW5jdGlvbiB0byB1cGRhdGUgdGhlIHBpbnMgc3RhdGVcbiAgICAgICAgICAvLyAtIGNsZWFyIHRoZSB1c2VyJ3Mgd29yZHMgaW4gdGhlIGRhdGFiYXNlXG4gICAgICAgICAgYXdhaXQgY2xlYXJQaW5zKCk7IC8vIEFzc3VtaW5nIGNsZWFyUGlucyBpcyBhIGZ1bmN0aW9uIHRvIGNsZWFyIHRoZSBwaW5zIGluIHRoZSBkYXRhYmFzZVxuICAgICAgICB9fVxuICAgICAgICAvLyBIYW5kbGVzIGNsZWFyaW5nIHRoZSB1c2VycyBzdG9yZWQgcGluc1xuICAgICAgPlxuICAgICAgICBDbGVhciBQaW5zXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2hhcHB5Mm5hL0Rlc2t0b3AvbWFwcy1temhlbmczNy1hc3VuNTkvY2xpZW50L3NyYy9jb21wb25lbnRzL01hcGJveC50c3gifQ==