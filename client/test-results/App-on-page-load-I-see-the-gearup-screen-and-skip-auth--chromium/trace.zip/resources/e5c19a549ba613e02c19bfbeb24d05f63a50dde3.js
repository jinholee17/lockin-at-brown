import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MapsGearup.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4ea8f8d0"; const useState = __vite__cjsImport3_react["useState"];
import FirestoreDemo from "/src/components/FirestoreDemo.tsx";
import Mapbox from "/src/components/Mapbox.tsx";
var Section = /* @__PURE__ */ ((Section2) => {
  Section2["FIRESTORE_DEMO"] = "FIRESTORE_DEMO";
  Section2["MAP_DEMO"] = "MAP_DEMO";
  return Section2;
})(Section || {});
export default function MapsGearup() {
  _s();
  const [section, setSection] = useState("FIRESTORE_DEMO" /* FIRESTORE_DEMO */);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { "aria-label": "Gearup Title", children: "Maps Gearup" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => setSection("FIRESTORE_DEMO" /* FIRESTORE_DEMO */), children: "Section 1: Firestore Demo" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => setSection("MAP_DEMO" /* MAP_DEMO */), children: "Section 2: Mapbox Demo" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    section === "FIRESTORE_DEMO" /* FIRESTORE_DEMO */ ? /* @__PURE__ */ jsxDEV(FirestoreDemo, {}, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx",
      lineNumber: 25,
      columnNumber: 45
    }, this) : null,
    section === "MAP_DEMO" /* MAP_DEMO */ ? /* @__PURE__ */ jsxDEV(Mapbox, {}, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx",
      lineNumber: 26,
      columnNumber: 39
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_s(MapsGearup, "euUyWhgtDVK5azHzsxZr3zKhSpg=");
_c = MapsGearup;
var _c;
$RefreshReg$(_c, "MapsGearup");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/MapsGearup.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEJOLFNBQVNBLGdCQUFnQjtBQUN6QixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsWUFBWTtBQUVuQixJQUFLQyxVQUFMLGtCQUFLQSxhQUFMO0FBQ0VDLCtCQUFpQjtBQUNqQkMseUJBQVc7QUFGUkY7QUFBQUE7QUFTTCx3QkFBd0JHLGFBQWE7QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSVQsU0FBa0JHLHFDQUFzQjtBQUV0RSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLGNBQVcsZ0JBQWUsMkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUN6Qyx1QkFBQyxZQUFPLFNBQVMsTUFBTU0sV0FBV04scUNBQXNCLEdBQUUseUNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU1NLFdBQVdOLHlCQUFnQixHQUFFLHNDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDSyxZQUFZTCx3Q0FBeUIsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLElBQU07QUFBQSxJQUN6REssWUFBWUwsNEJBQW1CLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPLElBQU07QUFBQSxPQVQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFDSSxHQWhCdUJELFlBQVU7QUFBQUksS0FBVko7QUFBVSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJGaXJlc3RvcmVEZW1vIiwiTWFwYm94IiwiU2VjdGlvbiIsIkZJUkVTVE9SRV9ERU1PIiwiTUFQX0RFTU8iLCJNYXBzR2VhcnVwIiwiX3MiLCJzZWN0aW9uIiwic2V0U2VjdGlvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTWFwc0dlYXJ1cC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBGaXJlc3RvcmVEZW1vIGZyb20gXCIuL0ZpcmVzdG9yZURlbW9cIjtcbmltcG9ydCBNYXBib3ggZnJvbSBcIi4vTWFwYm94XCI7XG5cbmVudW0gU2VjdGlvbiB7XG4gIEZJUkVTVE9SRV9ERU1PID0gXCJGSVJFU1RPUkVfREVNT1wiLFxuICBNQVBfREVNTyA9IFwiTUFQX0RFTU9cIixcbn1cbi8qKlxuICogU2V0cyB1cCB0aGUgbWFwIGxheW91dCBpbiB0aGUgZnJvbnQgZW5kLiBIYXMgdGhlIGZhdm9yaXRlIHdvcmQgc3RvYXJnZSBhbmQgbWFwcyBvcHRpb25zXG4gKlxuICogQHJldHVybnNcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWFwc0dlYXJ1cCgpIHtcbiAgY29uc3QgW3NlY3Rpb24sIHNldFNlY3Rpb25dID0gdXNlU3RhdGU8U2VjdGlvbj4oU2VjdGlvbi5GSVJFU1RPUkVfREVNTyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgxIGFyaWEtbGFiZWw9XCJHZWFydXAgVGl0bGVcIj5NYXBzIEdlYXJ1cDwvaDE+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlY3Rpb24oU2VjdGlvbi5GSVJFU1RPUkVfREVNTyl9PlxuICAgICAgICBTZWN0aW9uIDE6IEZpcmVzdG9yZSBEZW1vXG4gICAgICA8L2J1dHRvbj5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VjdGlvbihTZWN0aW9uLk1BUF9ERU1PKX0+XG4gICAgICAgIFNlY3Rpb24gMjogTWFwYm94IERlbW9cbiAgICAgIDwvYnV0dG9uPlxuICAgICAge3NlY3Rpb24gPT09IFNlY3Rpb24uRklSRVNUT1JFX0RFTU8gPyA8RmlyZXN0b3JlRGVtbyAvPiA6IG51bGx9XG4gICAgICB7c2VjdGlvbiA9PT0gU2VjdGlvbi5NQVBfREVNTyA/IDxNYXBib3ggLz4gOiBudWxsfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaGFwcHkybmEvRGVza3RvcC9tYXBzLW16aGVuZzM3LWFzdW41OS9jbGllbnQvc3JjL2NvbXBvbmVudHMvTWFwc0dlYXJ1cC50c3gifQ==