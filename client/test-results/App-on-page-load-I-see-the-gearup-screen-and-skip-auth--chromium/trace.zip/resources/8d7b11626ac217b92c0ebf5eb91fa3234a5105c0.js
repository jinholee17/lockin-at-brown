import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { initializeApp } from "/node_modules/.vite/deps/firebase_app.js?v=4ea8f8d0";
import "/src/styles/App.css";
import MapsGearup from "/src/components/MapsGearup.tsx";
import AuthRoute from "/src/components/auth/AuthRoute.tsx";
const firebaseConfig = {
  apiKey: process.env.API_KEY,
  authDomain: process.env.AUTH_DOMAIN,
  projectId: process.env.PROJECT_ID,
  storageBucket: process.env.STORAGE_BUCKET,
  messagingSenderId: process.env.MESSAGING_SENDER_ID,
  appId: process.env.APP_ID
};
initializeApp(firebaseConfig);
function App() {
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: /* @__PURE__ */ jsxDEV(AuthRoute, { gatedContent: /* @__PURE__ */ jsxDEV(MapsGearup, {}, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/App.tsx",
    lineNumber: 38,
    columnNumber: 32
  }, this) }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/App.tsx",
    lineNumber: 38,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/App.tsx",
    lineNumber: 37,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0MrQjtBQXRDL0IsMkJBQXNCO0FBQXNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDNUMsT0FBTztBQUNQLE9BQU9BLGdCQUFnQjtBQUN2QixPQUFPQyxlQUFlO0FBYXRCLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCQyxRQUFRQyxRQUFRQyxJQUFJQztBQUFBQSxFQUNwQkMsWUFBWUgsUUFBUUMsSUFBSUc7QUFBQUEsRUFDeEJDLFdBQVdMLFFBQVFDLElBQUlLO0FBQUFBLEVBQ3ZCQyxlQUFlUCxRQUFRQyxJQUFJTztBQUFBQSxFQUMzQkMsbUJBQW1CVCxRQUFRQyxJQUFJUztBQUFBQSxFQUMvQkMsT0FBT1gsUUFBUUMsSUFBSVc7QUFDckI7QUFLQUMsY0FBY2YsY0FBYztBQU81QixTQUFTZ0IsTUFBTTtBQUNiLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsYUFBVSxjQUFjLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBVyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEtBTlFEO0FBUVQsZUFBZUE7QUFBSSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTWFwc0dlYXJ1cCIsIkF1dGhSb3V0ZSIsImZpcmViYXNlQ29uZmlnIiwiYXBpS2V5IiwicHJvY2VzcyIsImVudiIsIkFQSV9LRVkiLCJhdXRoRG9tYWluIiwiQVVUSF9ET01BSU4iLCJwcm9qZWN0SWQiLCJQUk9KRUNUX0lEIiwic3RvcmFnZUJ1Y2tldCIsIlNUT1JBR0VfQlVDS0VUIiwibWVzc2FnaW5nU2VuZGVySWQiLCJNRVNTQUdJTkdfU0VOREVSX0lEIiwiYXBwSWQiLCJBUFBfSUQiLCJpbml0aWFsaXplQXBwIiwiQXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGluaXRpYWxpemVBcHAgfSBmcm9tIFwiZmlyZWJhc2UvYXBwXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvQXBwLmNzc1wiO1xuaW1wb3J0IE1hcHNHZWFydXAgZnJvbSBcIi4vTWFwc0dlYXJ1cFwiO1xuaW1wb3J0IEF1dGhSb3V0ZSBmcm9tIFwiLi9hdXRoL0F1dGhSb3V0ZVwiO1xuXG4vLyBSRU1FTUJFUiBUTyBQVVQgWU9VUiBBUEkgS0VZIElOIEEgRk9MREVSIFRIQVQgSVMgR0lUSUdOT1JFRCEhXG4vLyAoZm9yIGluc3RhbmNlLCAvc3JjL3ByaXZhdGUvYXBpX2tleS50c3gpXG4vL2ltcG9ydCB7QVBJX0tFWX0gZnJvbSBcIi4vcHJpdmF0ZS9hcGlfa2V5XCJcblxuLyoqXG4gKiBNYWluIHByb2dyYW0gdGhhdCBzdGFydHMgdGhlIHByb2dyYW0gZnJvbnQgZW5kXG4gKi9cblxuLyoqXG4gKiBjb25maWd1cmF0aW9uIGZvciBmaXJlYmFzZVxuICovXG5jb25zdCBmaXJlYmFzZUNvbmZpZyA9IHtcbiAgYXBpS2V5OiBwcm9jZXNzLmVudi5BUElfS0VZLFxuICBhdXRoRG9tYWluOiBwcm9jZXNzLmVudi5BVVRIX0RPTUFJTixcbiAgcHJvamVjdElkOiBwcm9jZXNzLmVudi5QUk9KRUNUX0lELFxuICBzdG9yYWdlQnVja2V0OiBwcm9jZXNzLmVudi5TVE9SQUdFX0JVQ0tFVCxcbiAgbWVzc2FnaW5nU2VuZGVySWQ6IHByb2Nlc3MuZW52Lk1FU1NBR0lOR19TRU5ERVJfSUQsXG4gIGFwcElkOiBwcm9jZXNzLmVudi5BUFBfSUQsXG59O1xuXG4vKipcbiAqIGluaXRpYWxpemVzIGZpcmViYXNlIGFwcFxuICovXG5pbml0aWFsaXplQXBwKGZpcmViYXNlQ29uZmlnKTtcblxuLyoqXG4gKiBBIGZ1bmN0aW9uIHRoYXQgcmVkZXJzIHRoZSBlbnRpcmUgQVBQIGluIHRoZSB0b3AgbGV2ZWwuXG4gKlxuICogQHJldHVybnMgVGhlIGVudGlyZSBNYXAgYXBwIGFuZCBpdHMgcmVsYXRpdmUgY29tcG9uZW50c1xuICovXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJBcHBcIj5cbiAgICAgIDxBdXRoUm91dGUgZ2F0ZWRDb250ZW50PXs8TWFwc0dlYXJ1cCAvPn0gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiIvVXNlcnMvaGFwcHkybmEvRGVza3RvcC9tYXBzLW16aGVuZzM3LWFzdW41OS9jbGllbnQvc3JjL2NvbXBvbmVudHMvQXBwLnRzeCJ9