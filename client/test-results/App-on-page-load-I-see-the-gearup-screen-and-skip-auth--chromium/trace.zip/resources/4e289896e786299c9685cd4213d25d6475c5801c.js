import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/LoginLogout.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { getAuth, GoogleAuthProvider, signInWithPopup } from "/node_modules/.vite/deps/firebase_auth.js?v=4ea8f8d0";
import { addLoginCookie, removeLoginCookie } from "/src/utils/cookie.ts";
const Login = (props) => {
  const auth = getAuth();
  const signInWithGoogle = async () => {
    try {
      const response = await signInWithPopup(auth, new GoogleAuthProvider());
      const userEmail = response.user.email || "";
      if (userEmail.endsWith("@brown.edu")) {
        console.log(response.user.uid);
        addLoginCookie(response.user.uid);
        props.setLogin(true);
      } else {
        await auth.signOut();
        console.log("User not allowed. Signed out.");
      }
    } catch (error) {
      console.log(error);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "login-box", children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Login Page" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "google-login-button", onClick: () => signInWithGoogle(), disabled: props.loggedIn, children: "Sign in with Google" }, void 0, false, {
      fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
    lineNumber: 40,
    columnNumber: 10
  }, this);
};
_c = Login;
const Logout = (props) => {
  const signOut = () => {
    removeLoginCookie();
    props.setLogin(false);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "logout-box", children: /* @__PURE__ */ jsxDEV("button", { className: "SignOut", onClick: () => signOut(), children: "Sign Out" }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
    lineNumber: 60,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
    lineNumber: 59,
    columnNumber: 10
  }, this);
};
_c2 = Logout;
const LoginLogout = (props) => {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: !props.loggedIn ? /* @__PURE__ */ jsxDEV(Login, { ...props }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
    lineNumber: 74,
    columnNumber: 31
  }, this) : /* @__PURE__ */ jsxDEV(Logout, { ...props }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
    lineNumber: 74,
    columnNumber: 54
  }, this) }, void 0, false, {
    fileName: "/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx",
    lineNumber: 74,
    columnNumber: 10
  }, this);
};
_c3 = LoginLogout;
export default LoginLogout;
var _c, _c2, _c3;
$RefreshReg$(_c, "Login");
$RefreshReg$(_c2, "Logout");
$RefreshReg$(_c3, "LoginLogout");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/happy2na/Desktop/maps-mzheng37-asun59/client/src/components/auth/LoginLogout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNNLFNBdUNHLFVBdkNIO0FBM0NOLDJCQUFrQkE7QUFBb0JDO0FBQXVCO0FBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRTVFLFNBQVNDLGdCQUFnQkMseUJBQXlCO0FBZWxELE1BQU1DLFFBQW1EQyxXQUFVO0FBQ2pFLFFBQU1DLE9BQU9DLFFBQVE7QUFFckIsUUFBTUMsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTVIsZ0JBQWdCSyxNQUFNLElBQUlOLG1CQUFtQixDQUFDO0FBQ3JFLFlBQU1VLFlBQVlELFNBQVNFLEtBQUtDLFNBQVM7QUFHekMsVUFBSUYsVUFBVUcsU0FBUyxZQUFZLEdBQUc7QUFDcENDLGdCQUFRQyxJQUFJTixTQUFTRSxLQUFLSyxHQUFHO0FBRTdCZCx1QkFBZU8sU0FBU0UsS0FBS0ssR0FBRztBQUNoQ1gsY0FBTVksU0FBUyxJQUFJO0FBQUEsTUFDckIsT0FBTztBQUVMLGNBQU1YLEtBQUtZLFFBQVE7QUFDbkJKLGdCQUFRQyxJQUFJLCtCQUErQjtBQUFBLE1BQzdDO0FBQUEsSUFDRixTQUFTSSxPQUFPO0FBQ2RMLGNBQVFDLElBQUlJLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsUUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLFlBQ0MsV0FBVSx1QkFDVixTQUFTLE1BQU1YLGlCQUFpQixHQUNoQyxVQUFVSCxNQUFNZSxVQUFTLG1DQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQ0FDLEtBckNNakI7QUEyQ04sTUFBTWtCLFNBQW9EakIsV0FBVTtBQUNsRSxRQUFNYSxVQUFVQSxNQUFNO0FBQ3BCZixzQkFBa0I7QUFDbEJFLFVBQU1ZLFNBQVMsS0FBSztBQUFBLEVBQ3RCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxZQUFPLFdBQVUsV0FBVSxTQUFTLE1BQU1DLFFBQVEsR0FBRSx3QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFFQUssTUFmTUQ7QUFxQk4sTUFBTUUsY0FBeURuQixXQUFVO0FBQ3ZFLFNBQU8sbUNBQUcsV0FBQ0EsTUFBTWUsV0FBVyx1QkFBQyxTQUFNLEdBQUlmLFNBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpQixJQUFNLHVCQUFDLFVBQU8sR0FBSUEsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWtCLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0U7QUFDM0U7QUFBRW9CLE1BRklEO0FBSU4sZUFBZUE7QUFBWSxJQUFBSCxJQUFBRSxLQUFBRTtBQUFBQyxhQUFBTCxJQUFBO0FBQUFLLGFBQUFILEtBQUE7QUFBQUcsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIkdvb2dsZUF1dGhQcm92aWRlciIsInNpZ25JbldpdGhQb3B1cCIsImFkZExvZ2luQ29va2llIiwicmVtb3ZlTG9naW5Db29raWUiLCJMb2dpbiIsInByb3BzIiwiYXV0aCIsImdldEF1dGgiLCJzaWduSW5XaXRoR29vZ2xlIiwicmVzcG9uc2UiLCJ1c2VyRW1haWwiLCJ1c2VyIiwiZW1haWwiLCJlbmRzV2l0aCIsImNvbnNvbGUiLCJsb2ciLCJ1aWQiLCJzZXRMb2dpbiIsInNpZ25PdXQiLCJlcnJvciIsImxvZ2dlZEluIiwiX2MiLCJMb2dvdXQiLCJfYzIiLCJMb2dpbkxvZ291dCIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luTG9nb3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRBdXRoLCBHb29nbGVBdXRoUHJvdmlkZXIsIHNpZ25JbldpdGhQb3B1cCB9IGZyb20gXCJmaXJlYmFzZS9hdXRoXCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBhZGRMb2dpbkNvb2tpZSwgcmVtb3ZlTG9naW5Db29raWUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvY29va2llXCI7XG5cbi8qKlxuICogaW50ZXJmYWNlIHRvIG1hbmFnZSBsb2dpbiBlbGVtZW50XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSUxvZ2luUGFnZVByb3BzIHtcbiAgbG9nZ2VkSW46IGJvb2xlYW47XG4gIHNldExvZ2luOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxib29sZWFuPj47XG59XG4vKipcbiAqIE1hbmFnZSBsb2ctaW5cbiAqXG4gKiBAcGFyYW0gcHJvcHMgRnVuY3Rpb24gdGhhdCBoYW5kbGVzIGxvZ2dpbiBpbi4gSXQgdXNlcyBmaXJlYmFzZSB0byBlbnN1cmUgb25seSBicm93biBlbWFpc2wgY2FuIGxvZ2luXG4gKiBAcmV0dXJucyBKU1ggY29tcG9uZW50IGZvciBsb2dpbiBwcm9tcHRcbiAqL1xuY29uc3QgTG9naW46IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50PElMb2dpblBhZ2VQcm9wcz4gPSAocHJvcHMpID0+IHtcbiAgY29uc3QgYXV0aCA9IGdldEF1dGgoKTtcblxuICBjb25zdCBzaWduSW5XaXRoR29vZ2xlID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHNpZ25JbldpdGhQb3B1cChhdXRoLCBuZXcgR29vZ2xlQXV0aFByb3ZpZGVyKCkpO1xuICAgICAgY29uc3QgdXNlckVtYWlsID0gcmVzcG9uc2UudXNlci5lbWFpbCB8fCBcIlwiO1xuXG4gICAgICAvLyBDaGVjayBpZiB0aGUgZW1haWwgZW5kcyB3aXRoIHRoZSBhbGxvd2VkIGRvbWFpblxuICAgICAgaWYgKHVzZXJFbWFpbC5lbmRzV2l0aChcIkBicm93bi5lZHVcIikpIHtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UudXNlci51aWQpO1xuICAgICAgICAvLyBhZGQgdW5pcXVlIHVzZXIgaWQgYXMgYSBjb29raWUgdG8gdGhlIGJyb3dzZXIuXG4gICAgICAgIGFkZExvZ2luQ29va2llKHJlc3BvbnNlLnVzZXIudWlkKTtcbiAgICAgICAgcHJvcHMuc2V0TG9naW4odHJ1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBVc2VyIGlzIG5vdCBhbGxvd2VkLCBzaWduIHRoZW0gb3V0IGFuZCBzaG93IGEgbWVzc2FnZVxuICAgICAgICBhd2FpdCBhdXRoLnNpZ25PdXQoKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJVc2VyIG5vdCBhbGxvd2VkLiBTaWduZWQgb3V0LlwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tYm94XCI+XG4gICAgICA8aDE+TG9naW4gUGFnZTwvaDE+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIGNsYXNzTmFtZT1cImdvb2dsZS1sb2dpbi1idXR0b25cIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzaWduSW5XaXRoR29vZ2xlKCl9XG4gICAgICAgIGRpc2FibGVkPXtwcm9wcy5sb2dnZWRJbn1cbiAgICAgID5cbiAgICAgICAgU2lnbiBpbiB3aXRoIEdvb2dsZVxuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuLyoqXG4gKiBNYW5hZ2UgbG9nb3V0XG4gKlxuICogQHBhcmFtIHByb3BzIExvZ291dCBjb21wb25lbnQgdGhhdCBkZWFscyB3aXRoIHRoZSB1c2VyIGxvZ2dpbiBvdXQgc28gdGhleSBjYW4gbm90IGhhdmUgYWNjZXNzIHRvIHRoZSBtYXBzIG1haW4gcGFnZVxuICogQHJldHVybnMgSlNYIGZvciBsb2ctb3V0XG4gKi9cbmNvbnN0IExvZ291dDogUmVhY3QuRnVuY3Rpb25Db21wb25lbnQ8SUxvZ2luUGFnZVByb3BzPiA9IChwcm9wcykgPT4ge1xuICBjb25zdCBzaWduT3V0ID0gKCkgPT4ge1xuICAgIHJlbW92ZUxvZ2luQ29va2llKCk7XG4gICAgcHJvcHMuc2V0TG9naW4oZmFsc2UpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsb2dvdXQtYm94XCI+XG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cIlNpZ25PdXRcIiBvbkNsaWNrPXsoKSA9PiBzaWduT3V0KCl9PlxuICAgICAgICBTaWduIE91dFxuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG4vKipcbiAqIFRvIFJlbmRlciBhbmQgbWFuYWdlIGVudGlyZSBsb2ctaW4gYW5kIGxvZy1vdXQgc3lzdGVtXG4gKlxuICogQHBhcmFtIHByb3BzXG4gKiBAcmV0dXJucyBKU1ggZm9yIGVudGlyZSBsb2dpbiBhbmQgbG9nLW91dCBtYW5hZ2VtZW50XG4gKi9cbmNvbnN0IExvZ2luTG9nb3V0OiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudDxJTG9naW5QYWdlUHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiA8PnshcHJvcHMubG9nZ2VkSW4gPyA8TG9naW4gey4uLnByb3BzfSAvPiA6IDxMb2dvdXQgey4uLnByb3BzfSAvPn08Lz47XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkxvZ291dDtcbiJdLCJmaWxlIjoiL1VzZXJzL2hhcHB5Mm5hL0Rlc2t0b3AvbWFwcy1temhlbmczNy1hc3VuNTkvY2xpZW50L3NyYy9jb21wb25lbnRzL2F1dGgvTG9naW5Mb2dvdXQudHN4In0=